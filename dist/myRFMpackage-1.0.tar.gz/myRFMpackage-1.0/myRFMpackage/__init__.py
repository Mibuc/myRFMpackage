# __init__.py

# from calculateRFM.py import the function calculateRFM()
from .calculateRFM import calculateRFM
