myRFMpackage
------------

"myRFMpackage" provides basic funcitonality for working with customer data.

Further description...
